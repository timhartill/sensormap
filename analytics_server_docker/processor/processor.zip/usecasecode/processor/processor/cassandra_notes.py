#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jun 30 16:03:25 2019

@author: tim hartill

cassandra Utilities

see: https://stackoverflow.com/questions/38696316/how-to-list-all-cassandra-tables
and: https://pypi.org/project/cassandra-driver/
and: http://cassandra.apache.org/doc/latest/cql/

session.execute('USE system_schema')  # change to system keyspace

#list keyspaces:
#---------------
rows = session.execute('SELECT * FROM system_schema.keyspaces') 
for row in rows:
    print('ROW:', row)  # or row.colname or row[0]...

# list tables
#------------    
rows = session.execute("SELECT * FROM system_schema.tables WHERE keyspace_name = 'metromind'")
print(rows.column_names) # rows object available columns
for row in rows:
    print('Table:', row.table_name)    

# list table columns
#-------------------
rows = session.execute("SELECT * FROM system_schema.columns WHERE keyspace_name = 'metromind' AND table_name = 'aisle'")
print(rows.column_names)    
for row in rows:
    print('Column:', row.table_name, row.column_name, row.type, row.kind, row.clustering_order)

"""
from cassandra.cluster import Cluster
import json
import iso8601


def show_rows(rows, max_rows=10):
    i = 0
    for row in rows:
        print('ROW ', i)
        print(row)
        i += 1
        if i > max_rows: break
    return

def return_json(rows, max_rows=10):
    json_list = []
    i = 0
    for row in rows:
        #print('ROW ', i)
        #print(row)
        json_list.append(json.loads(row.json))
        i += 1
        if i > max_rows: break
    return json_list

def get_timestamp_str(datetime_obj):
    """Return the string formatted timestamp for a given datetime object.
    We assume that the datetime object is in the UTC timezone
    Return format = '<YYYY>-<mm>-<dd>T<HH>:<MM>:<SS.SSS>Z'
    where YYYY = 4 digit year
        mm = 2 digit month
        dd = 2 digit date
        HH = 2 digit hour ( 0  to 23 )
        HH = 2 digit minute ( 0  to 59 )
        SS.SSS = Seconds (upto 5 dec places accuracy, 00.00000 to 59.99999)
        Z signifies the UTC time-zone
    Returns:
        [string] -- Timestamp string
    """
    (dtobj, micro) = datetime_obj.strftime('%Y-%m-%dT%H:%M:%S.%f').split('.')
    dtobj = "%s.%03dZ" % (dtobj, int(micro) / 1000)
    return dtobj


db = 'localhost'
keyspace = 'metromind'

msgid = 'endeavor-P1'

cluster = Cluster([db])
session = cluster.connect(keyspace)

session.execute('USE ' + keyspace)

rows = session.execute("select count(*) from objectmarker")
rows.one()
rows = session.execute("select count(*) from fixedzone")
rows.one()
rows = session.execute("select count(*) from flowrate")
rows.one()
rows = session.execute("select count(*) from aisle")
rows.one()
rows = session.execute("select count(*) from ParkingSpotDelta")
rows.one()
rows = session.execute("select count(*) from ParkingSpotPlayback")
rows.one()
rows = session.execute("select count(*) from ParkingSpotState")
rows.one()
rows = session.execute("select count(*) from car_count")
rows.one()

rows = session.execute("select * from flowrate")
show_rows(rows)
rows = session.execute("select * from aisle")  #PRIMARY KEY (messageid, timestamp)
show_rows(rows)
rows = session.execute("select * from ParkingSpotDelta")  #PRIMARY KEY ((garageid, level, sensortype), timestamp, spotid)
show_rows(rows)
rows = session.execute("select * from ParkingSpotPlayback") #PRIMARY KEY ((garageid, level, sensortype, spotid), timestamp)
show_rows(rows)
rows = session.execute("select * from ParkingSpotState") #PRIMARY KEY ((garageid, level), spotid)
show_rows(rows)
rows = session.execute("select * from car_count") #
show_rows(rows)

rows = session.execute("select JSON * from aisle")  #PRIMARY KEY (messageid, timestamp)
cass_json_list = return_json(rows, max_rows=10000)
cass_json_list[0]

rows = session.execute("select * from aisle where messageid='endeavor-P1' and timestamp='2019-07-05 05:12:42.828Z' ALLOW FILTERING")
show_rows(rows)

rows = session.execute("select JSON * from aisle where messageid='endeavor-P1' order by timestamp DESC ALLOW FILTERING")
cass_json_list = return_json(rows, max_rows=10000)
cass_json_list[0]  # DESC puts earliest timestamp first...

rows = session.execute("select JSON * from ParkingSpotDelta where garageid='endeavor' and level='P1' and sensortype='Camera' order by timestamp DESC ALLOW FILTERING")
cass_json_list = return_json(rows, max_rows=10000)
cass_json_list[0]  # DESC puts earliest timestamp first...

rows = session.execute("select JSON * from ParkingSpotState where garageid='endeavor' and level='P1' ALLOW FILTERING")
cass_json_list = return_json(rows, max_rows=10000)
cass_json_list[0]  

rows = session.execute("select JSON * from objectmarker where messageid='endeavor-P1' order by timestamp DESC ALLOW FILTERING")
cass_json_list = return_json(rows, max_rows=10000)
cass_json_list[0]  # DESC puts earliest timestamp first...

rows = session.execute("select JSON * from fixedzone where garageid='endeavor' and level='P1' ALLOW FILTERING")
cass_json_list = return_json(rows, max_rows=10000)
cass_json_list[0]  


ins_stmt = "INSERT INTO objectmarker JSON ?"
ins_stmt = session.prepare(ins_stmt)  #MUST prepare the stmt, INSERT wont work otherwise
curr_msg = {'@timestamp': '2019-07-14T06:38:06.05110Z',
 'analyticsModule': {'description': '',
  'id': '',
  'source': '',
  'version': '1.0'},
 'event': {'id': '38f36dad-ccf6-49ac-be53-96bf23a438fd', 'type': 'detection'},
 'mdsversion': '2.0',
 'messageid': '1358bb49-d62b-49b7-a82f-8e2735011c8f',
 'object': {'bbox': {'bottomrightx': 946,
   'bottomrighty': 1072,
   'topleftx': 888,
   'toplefty': 954},
  'coordinate': {'x': -98.93395233154297, 'y': 185.81008911132812, 'z': 0.0},
  'direction': 0.0,
  'orientation': 0.0,
  'speed': 0.0,
  'id': '7136947',
  'trackerid': '7136947',
  'classid': '1',
  'classdesc': 'person',
  'confidence': 1.0,
  'centroid': {'x': -99.02274322509766, 'y': 185.83059692382812, 'z': 0.0},
  'polygon': {'a': {'x': 0.0, 'y': 0.0, 'z': 0.0},
   'b': {'x': 0.0, 'y': 0.0, 'z': 0.0},
   'c': {'x': 0.0, 'y': 0.0, 'z': 0.0},
   'd': {'x': 0.0, 'y': 0.0, 'z': 0.0}},
  'location': {'alt': 0.0, 'lat': 0.0, 'lon': 0.0},
  'signature': []},
 'place': {'subplace': {'coordinate': {'x': 0.0, 'y': 0.0, 'z': 0.0},
   'id': '0',
   'level': 'P1',
   'name': ''},
  'id': '0',
  'location': {'alt': 0.0, 'lat': 0.0, 'lon': 0.0},
  'name': 'endeavor',
  'type': 'facility'},
 'zone': {'shapetype': '',
  'radius': 0.0,
  'poly1': {'a': {'x': 0.0, 'y': 0.0, 'z': 0.0},
   'b': {'x': 0.0, 'y': 0.0, 'z': 0.0},
   'c': {'x': 0.0, 'y': 0.0, 'z': 0.0},
   'd': {'x': 0.0, 'y': 0.0, 'z': 0.0}}},
 'sensor': {'coordinate': {'x': 0.0, 'y': 0.0, 'z': 0.0},
  'description': 'fixed',
  'id': '0500',
  'location': {'alt': 0.0, 'lat': 0.0, 'lon': 0.0},
  'type': 'camera'},
 'videoPath': 'VIRAT_S_050000_01_000207_000361'}

curr_msg['timestamp'] = curr_msg['@timestamp']
del curr_msg['@timestamp']
timestamp = iso8601.parse_date(curr_msg['timestamp'])
timestr = get_timestamp_str(timestamp)  # this version only outputs to 3 dec pts otherwise cassandra error
curr_msg['timestamp'] = timestr
#del curr_msg['object']['signature']
 
rows = session.execute(ins_stmt, [json.dumps(curr_msg)])

rows = session.execute("select JSON * from objectmarker")
cass_json_list = return_json(rows, max_rows=35000)
cass_json_list[0]  # DESC puts earliest timestamp first...



# view tables and table columns
session.execute('USE system_schema')  # change to system keyspace

#view tables
rows = session.execute("SELECT * FROM system_schema.tables WHERE keyspace_name = '" + keyspace + "'")
print(rows.column_names) # rows object available columns
for row in rows:
    print('Table:', row.table_name)

#view columns in a table    
rows = session.execute("SELECT * FROM system_schema.columns WHERE keyspace_name = 'metromind' AND table_name = 'aisle'")
print(rows.column_names)    
for row in rows:
    print('Column:', row.table_name, row.column_name, row.type, row.kind, row.clustering_order) 

rows = session.execute("SELECT * FROM system_schema.columns WHERE keyspace_name = 'metromind' AND table_name = 'objectmarker'")
print(rows.column_names)    
for row in rows:
    print('Column:', row.table_name, row.column_name, row.type, row.kind, row.clustering_order) 

rows = session.execute("SELECT * FROM system_schema.columns WHERE keyspace_name = 'metromind' AND table_name = 'fixedzone'")
print(rows.column_names)    
for row in rows:
    print('Column:', row.table_name, row.column_name, row.type, row.kind, row.clustering_order) 



